# backend/appcreate.py

from backend.app import create_app
from backend.models import db

# Create the app
app1 = create_app()

# Initialize the database
with app1.app_context():
    db.create_all()

from backend.control import *

if __name__ == '__main__':
    app1.run(host='127.0.0.1', port=5000, debug=True)
