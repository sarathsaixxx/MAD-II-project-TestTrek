import csv
import io
from backend.celconapp import celery,app1  
from backend.models import User, Score 
from smtplib import SMTP
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import csv
from celery.schedules import crontab

# SMTP Configuration
SMTP_HOST = "localhost"
SMTP_PORT = 1025
SENDER_EMAIL = "do-not-reply@gsender.com"
SENDER_PASSWORD = "jefh zidq tdys zxoe"

# Function to send an email
def send_message(to, subject, content_body):
    msg = MIMEMultipart()
    msg["To"] = to
    msg["Subject"] = subject
    msg["From"] = SENDER_EMAIL
    msg.attach(MIMEText(content_body, "html"))

    with SMTP(host=SMTP_HOST, port=SMTP_PORT) as client:
        client.send_message(msg)
        client.quit()


# Celery Task: Send Daily Reminder
@celery.task(ignore_result=True)
def send_daily_reminder():
    with app1.app_context(): 
        users = User.query.all()
        for user in users:
            subject = "Daily Quiz Reminder"
            body = "<h3>Don't forget to take your daily quiz!</h3><a href= 'http://localhost:5173/login'>Click Here</a> to check in your Dashboard !! "
            send_message(user.email, subject, body)
        return "Daily reminders sent."

# Celery Task: Send Monthly Report
@celery.task(ignore_result=True)
def send_monthly_report():
    with app1.app_context():
        users = User.query.all()
        for user in users:
            scores = Score.query.filter_by(user_id=user.id).all()
            total_quizzes = len(scores)
            avg_score = sum(score.total_scored for score in scores) / total_quizzes if total_quizzes else 0
            subject = "Your Monthly Quiz Report"
            body = f"<h3>Monthly Report:</h3><p>Quizzes Taken: {total_quizzes}</p><p>Average Score: {avg_score:.2f}</p><p>For more information, check out your Dashboard: <a href= 'http://localhost:5173/login'>Click Here</a>"
            send_message(user.email, subject, body)
        return "Monthly reports sent."
 

@celery.task
def export_quiz_results(user_id, quiz_id): 
    output = io.StringIO()
    writer = csv.writer(output)
    
    writer.writerow(["User ID", "Quiz ID", "Score", "Timestamp1","Subject","Chapter"]) 
    
    scores = Score.query.filter_by(user_id=user_id, quiz_id=quiz_id).all()
    if not scores:
        return None 
    
    for score in scores:
        writer.writerow([score.user_id, score.quiz_id, score.total_scored, score.time_stamp_of_attempt,score.quiz.subject.name ,score.quiz.chapter.name]) 
    writer.writerow(["","","","","",""]) 
    
    
    
    return output.getvalue()  
 
 
@celery.on_after_finalize.connect  # Using `on_after_finalize` instead of `on_after_configure`
def setup_periodic_tasks(sender, **kwargs):
    #with app1.app_context():  # Ensure Flask app context
    sender.add_periodic_task(crontab(minute='*/1'), send_daily_reminder.s(), name="Daily Reminders")
    sender.add_periodic_task(crontab(minute='*/1'), send_monthly_report.s(), name="Monthly Reports") 