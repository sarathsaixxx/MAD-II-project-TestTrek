class Config():
    SQLALCHEMY_TRACK_MODIFICATIONS=False#to remove unnecessary things
    DEBUG=False#debug is false in production  
class LocalDevelopmentConfig(Config):
    SQLALCHEMY_DATABASE_URI="sqlite:///mychoice.sqlite3"
    DEBUG=True
    # WTF_CSRF_ENABLED=False
    SECURITY_PASSWORD_SALT='its9077myandwish'
    SECRET_KEY='itstoosecrretdadadada'
    SECURITY_PASSWORD_HASH='bcrypt'#because of this, if you store passwd's directly into our database, he/she will have full access to our db of millions of records

    CELERY_BROKER_URL = 'redis://localhost:6379'
    CELERY_RESULT_BACKEND = 'redis://localhost:6379'

    MAIL_SERVER = 'localhost'
    MAIL_PORT = 1025
    MAIL_USE_TLS = False
    MAIL_USE_SSL = False
    MAIL_USERNAME = None
    MAIL_PASSWORD = None
    MAIL_DEFAULT_SENDER = 'test@example.com'
