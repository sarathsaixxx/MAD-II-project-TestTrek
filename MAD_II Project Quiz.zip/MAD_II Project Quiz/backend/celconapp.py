# backend/celconapp.py

from backend.app import create_app, make_celery

# Initialize the Flask app
app1 = create_app()

# Initialize Celery
celery = make_celery(app1)
