# backend/app.py

from flask import Flask
from flask_security import Security, SQLAlchemyUserDatastore
from flask_mail import Mail
from flask_caching import Cache
from flask_cors import CORS
from celery import Celery
from backend.models import db, User, Role
from backend.db1 import db  # Import db from the new db.py

mail = Mail()
cache = Cache() 

def create_app():
    app = Flask(__name__)
    app.config.from_object("backend.config.LocalDevelopmentConfig")

    # Enable CORS
    CORS(app, supports_credentials=True, resources={r"/*": {
        "origins": ["http://localhost:5173"],
        "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"],
        "allow_credentials": True
    }})


    # Initialize database and security
    db.init_app(app)
    datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, datastore=datastore, register_blueprint=False)

    # Cache configuration
    app.config['CACHE_TYPE'] = 'redis'
    app.config['CACHE_REDIS_URL'] = 'redis://localhost:6379'

    mail.init_app(app)
    cache.init_app(app)

    return app

def make_celery(app):
    celery = Celery(
        app.import_name,
        broker="redis://localhost:6379",
        backend="redis://localhost:6379",
        timezone="Asia/Kolkata"
    )
    celery.conf.update(app.config)

    class ContextTask(celery.Task):
        """ Ensures Celery tasks run within Flask's application context """
        def __call__(self, *args, **kwargs):
            with app.app_context():
                return self.run(*args, **kwargs)

    celery.Task = ContextTask
    return celery
