from appcreate import app1 as app  
from flask import request, jsonify, Response 
from flask_login import logout_user # type: ignore
from flask_security import  verify_password, hash_password # type: ignore
from backend.models import *
from itsdangerous import URLSafeTimedSerializer# type: ignore 
from flask_jwt_extended import jwt_required, get_jwt_identity# type: ignore 
from appcreate import app1  # Import from config.py
from backend.celconapp import celery
from backend.tasks import send_daily_reminder, send_monthly_report,export_quiz_results
import matplotlib.pyplot as plt 
import time 
import io  

from flask_caching import Cache



with app1.app_context():
    datastore = app1.security.datastore





# Configure cache
cache = Cache(app, config={'CACHE_TYPE': 'simple'})  # Simple in-memory cache

@app.route('/dashboard/<int:user_id>', methods=['GET'])
@jwt_required()
@cache.cached(timeout=10, key_prefix="dashboard_{user_id}")  # Cache for 10 minutes

def dashboard(user_id):
    current_user_id = get_jwt_identity()
    if current_user_id != user_id:
        return jsonify({"msg": "Unauthorized access"}), 403

    user = User.query.get(user_id)
    if not user:
        return jsonify({"msg": "User not found"}), 404

    return jsonify({
        "id": user.id,
        "email": user.email,
        "full_name": user.full_name,
        "qualification": user.qualification,
        "dob": user.dob
    })
  
from flask import send_file   
 
@app.route('/user/<int:user_id>/summary/quiz/<int:quiz_id>', methods=['GET'])
def user_quiz_summary(user_id, quiz_id): 
    score_entry = Score.query.filter_by(user_id=user_id, quiz_id=quiz_id).first()
    
    if not score_entry:
        return jsonify({"error": "No score data found for this user and quiz"}), 404

    total_scored = score_entry.total_scored
 
    quiz = Quiz.query.get(quiz_id)
    if not quiz or not quiz.questions:
        return jsonify({"error": "Quiz data not found or no questions available"}), 404

    total_marks = len(quiz.questions)

    # Create bar chart
    _, ax = plt.subplots()
    ax.bar(["User Score", "Total Marks"], [total_scored, total_marks], color=['blue', 'gray'])
    
    ax.set_ylabel("Marks")
    ax.set_title(f"Quiz {quiz_id} Summary for User {user_id}")
    ax.set_ylim(0, total_marks + 5)

    # Convert plot to an image and send as response
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plt.close()

    return send_file(img, mimetype='image/png') 
 
@app.route('/user_score_chart/<int:user_id>', methods=['GET'])
def user_score_chart(user_id):
    scores = Score.query.filter_by(user_id=user_id).all()

    if not scores:
        return jsonify({'message': 'No scores found for this user'}), 404

    quiz_ids = [score.quiz_id for score in scores]
    total_scores = [score.total_scored for score in scores]
    quiz_labels = [f"Quiz {quiz_id}" for quiz_id in quiz_ids]

    plt.figure(figsize=(8, 5))
    plt.bar(quiz_labels, total_scores, color='blue', alpha=0.7, label="User Score")
    plt.xlabel("Quiz")
    plt.ylabel("Score")
    plt.title("User Score vs Total Marks")
    plt.xticks(rotation=45)
    plt.legend()

    # Save graph to a BytesIO buffer
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)

    return send_file(img, mimetype='image/png')

@app.route('/admin/chart/user_participation')
def user_participation_chart():
    users = User.query.all()
    user_labels = [user.email for user in users]
    quiz_counts = [len(user.scores) for user in users]

    _, ax = plt.subplots()
    ax.bar(user_labels, quiz_counts, color='blue')
    ax.set_xlabel("Users")
    ax.set_ylabel("Quizzes Attempted")
    ax.set_title("User Participation in Quizzes")
    plt.xticks(rotation=45, ha="right")

    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    return send_file(img, mimetype='image/png')

if __name__ == '__main__':
    app.run(debug=True)

@app.route('/admin/chart/quiz_performance')
def quiz_performance_chart():
    quizzes = Quiz.query.all()
    quiz_labels = [quiz.id for quiz in quizzes]
    avg_scores = [
        db.session.query(db.func.avg(Score.total_scored)).filter(Score.quiz_id == quiz.id).scalar() or 0
        for quiz in quizzes
    ]

    _, ax = plt.subplots()
    ax.bar(quiz_labels, avg_scores, color='green')
    ax.set_xlabel("Quiz ID")
    ax.set_ylabel("Average Score")
    ax.set_title("Quiz Performance Overview")

    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    return send_file(img, mimetype='image/png')



@app.get('/')
def home_page():
    return 'Hi'

@app.route('/logout', methods=['POST'])
def logout():
    logout_user() 
    return jsonify({"message": "Logged out successfully"}), 200

@app.route('/register', methods=['GET', 'POST'])
def register():
    print("Received request for registration")
    d = request.get_json()
    eml = d.get('email')
    pswd1 = d.get('password') 
    pswd = hash_password(pswd1)
    fl_nam = d.get('full_name')
    qual = d.get('qual')
    dob = d.get('dob')
    import uuid
    fs_unq = str(uuid.uuid4())
    if not eml:
        return jsonify({"msg": "fill the email"}), 400
    if not pswd:
        return jsonify({"msg": "fill the password"}), 400
    if not fl_nam:
        return jsonify({"msg": "fill the full name"}), 400
    if not qual:
        return jsonify({"msg": "fill the qualification"}), 400
    if not dob:
        return jsonify({"msg": "fill the dob"}), 400
    
    user = datastore.find_user(email=eml)
    
    from datetime import datetime
    print(dob)

    dob = datetime.strptime(dob, '%Y-%m-%d').date()

    if user:
        return jsonify({"msg": "user exist"}), 204
    
    
    datastore.create_user(email=eml, password=pswd, full_name=fl_nam, qualification=qual, dob=dob)
    db.session.commit()
    return jsonify({"msg": "Done"}), 200

@app.route('/login', methods=['GET', 'POST','OPTIONS']) 
def login():
    if request.method == "OPTIONS":  # Handle preflight
        return jsonify({"message": "CORS preflight successful"}), 200

    d = request.get_json()
    eml = d.get('email')
    pswd = d.get('password') 
    
    if not eml:
        return jsonify({"msg": "fill the email"}), 400
    if not pswd:
        return jsonify({"msg": "fill the password"}), 400
    
    user = datastore.find_user(email=eml)
    
    if not user:
        return jsonify({"msg": "no user found with this"}), 401
    if verify_password(pswd, user.password):
        serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])
        token = serializer.dumps(user.fs_uniquifier)
        return jsonify({'token': token, 'email': user.email, 'id': user.id}), 200
    return jsonify({'msg': 'invalid password'}), 400

@app.route('/user/<int:user_id>', methods=['GET'])
def get_user(user_id):
    user = User.query.get(user_id)  # Retrieve the user by id from the database
    if not user:
        return jsonify({"error": "User not found"}), 404

    # Return user data as JSON
    return jsonify({
        "user_id": user.id,
        "name": user.full_name,
        "email": user.email,
        "qualification": user.qualification,
        "dob": user.dob
    })

# Example of adding a new user (for testing purposes)
@app.route('/user', methods=['POST'])
def add_user():
    data = request.get_json()  # Get the JSON data sent in the request
    new_user = User(name=data['name'], email=data['email'])
    db.session.add(new_user)
    db.session.commit()
    return jsonify({"message": "User created", "id": new_user.id}), 201

@app.before_request
def handle_preflight():
    if request.method == 'OPTIONS':
        return jsonify({'status': 'OK'}), 200
  
@app.route('/subjects', methods=['POST'])
def add_subject():
    data = request.json
    new_subject = Subject(name=data['name'], description=data['description'])
    db.session.add(new_subject)
    db.session.commit()
    return jsonify({"message": "Subject added successfully!"})
 
@app.route('/subjects', methods=['GET'])
def get_subjects():
    subjects = Subject.query.all()
    return jsonify([{"id": sub.id, "name": sub.name, "description": sub.description} for sub in subjects])
 
@app.route('/chapters', methods=['POST'])
def add_chapter():
    data = request.json
    new_chapter = Chapter(name=data['name'], description=data['description'], subject_id=data['subject_id'])
    db.session.add(new_chapter)
    db.session.commit()
    return jsonify({"message": "Chapter added successfully!"}) 

from datetime import date

@app.route('/quizzes1', methods=['GET'])
def get_quizzes1():
    today = date.today()  # Get today's date
    quizzes = Quiz.query.filter(Quiz.date_of_quiz <= today).all()  # Filter out past quizzes
    
    return jsonify([{
        "id": q.id,
        "date": q.date_of_quiz.strftime("%Y-%m-%d"),
        "time": q.time_duration,
        "remarks": q.remarks,
        "subject_id": q.subject_id,
        "chapter_id": q.chapter_id,
        "num_questions": len(q.questions)
    } for q in quizzes])

@app.route('/quizzes', methods=['GET'])
def get_quizzes(): 
    quizzes = Quiz.query.all() # Filter out past quizzes
    
    return jsonify([{
        "id": q.id,
        "date": q.date_of_quiz.strftime("%Y-%m-%d"),
        "time": q.time_duration,
        "remarks": q.remarks,
        "subject_id": q.subject_id,
        "chapter_id": q.chapter_id,
        "num_questions": len(q.questions)
    } for q in quizzes])

    
@app.route('/quizzes/<int:quiz_id>', methods=['GET'])
def get_quiz(quiz_id):
    quiz = Quiz.query.get(quiz_id)
    if not quiz:
        return jsonify({'error': 'Quiz not found'}), 404
    return jsonify({
        'id': quiz.id,
        'name': quiz.remarks,
        'time_duration': quiz.time_duration,
        'questions': [
            {
                'id': q.id,
                'text': q.question_statement,
                'options': [q.option1, q.option2, q.option3, q.option4],
                'correct_answer': q.correct_answer
            }
            for q in quiz.questions
        ]
    })


@app.route('/quizzes', methods=['POST'])
def add_quiz():
    try:
        data = request.json  
        if "name" in data:
            return jsonify({"error": "'name' is not a valid field"}), 400
        
        #subject = Subject.query.filter_by(name=data['subject_name']).first() 
        #chapter = Chapter.query.filter_by(name=data['chapter_name']).first()
        
        new_quiz = Quiz(
            date_of_quiz=datetime.strptime(data.get('date'), "%Y-%m-%d").date(),
            time_duration=data.get('time'),
            remarks=data.get('remarks'),
            subject_id=data.get('subject_id'),
            chapter_id=data.get('chapter_id')
        )

        db.session.add(new_quiz)
        db.session.commit()
        return jsonify({"message": "Quiz added successfully!"}), 201

    except Exception as e:
        return jsonify({"error": str(e)}), 500
 
@app.route('/quizzes/<int:id>', methods=['PUT'])
def update_quiz(id):
    quiz = Quiz.query.get(id)
    if not quiz:
        return jsonify({"message": "Quiz not found"}), 404
    
    data = request.json
    quiz.date_of_quiz = datetime.strptime(data["date"], "%Y-%m-%d").date()
    quiz.time_duration = data["time"]
    quiz.remarks = data["remarks"]
    quiz.subject_id = data["subject_id"]
    quiz.chapter_id = data["chapter_id"]
    
    db.session.commit()
    return jsonify({"message": "Quiz updated successfully!"})

# Delete a quiz
@app.route('/quizzes/<int:id>', methods=['DELETE'])
def delete_quiz(id):
    quiz = Quiz.query.get(id)
    if not quiz:
        return jsonify({"message": "Quiz not found"}), 404
    db.session.delete(quiz)
    db.session.commit()
    return jsonify({"message": "Quiz deleted successfully!"})

@app.route('/questions/<int:quiz_id>', methods=['GET'])
def manage_questions(quiz_id):
    quiz = Question.query.get(quiz_id)
    if not quiz:
        return jsonify({'error': 'Quiz not found'}), 404
    
    questions = Question.query.filter_by(quiz_id=quiz_id).all()

    result = []
    for q in questions:
        options = [q.option1, q.option2, q.option3, q.option4]  # Collect all options
        
        result.append({
            'id': q.id,
            'text': q.question_statement,
            'options': [opt for opt in options if opt],  # Remove empty options
            'correct_option': q.correct_answer
        })
    
    return jsonify(result)
   
@app.route('/questions/<int:quiz_id>', methods=['POST'])
def add_question(quiz_id):
    data = request.json  
    print("Received data:", data)

    # Validate required fields
    if "question_statement" not in data or "options" not in data or "correct_answer" not in data:
        return jsonify({"error": "Missing required fields"}), 400

    if not isinstance(data["options"], list) or len(data["options"]) < 2:
        return jsonify({"error": "At least two options are required."}), 400

    if len(data["options"]) > 4:
        return jsonify({"error": "Maximum of 4 options allowed."}), 400
 
    new_question = Question(
        quiz_id=quiz_id,
        question_statement=data["question_statement"],
        option1=data["options"][0] if len(data["options"]) > 0 else None,
        option2=data["options"][1] if len(data["options"]) > 1 else None,
        option3=data["options"][2] if len(data["options"]) > 2 else None,
        option4=data["options"][3] if len(data["options"]) > 3 else None,
        correct_answer=data["correct_answer"]
    ) 
    
    try:
        db.session.add(new_question)
        db.session.commit()
        return jsonify({"message": "Question added successfully", "id": new_question.id}), 201
    except Exception as e:
        db.session.rollback()
        print("Error:", str(e))  # Print error for debugging
        return jsonify({"error": "Internal Server Error", "details": str(e)}), 500
@app.route("/questions1/<int:question_id>", methods=["GET"])
def get_question(question_id):
    question = Question.query.get(question_id)
    if not question:
        return jsonify({"error": "Question not found"}), 404

    options = [question.option1, question.option2, question.option3, question.option4]
    options = [opt for opt in options if opt]  # Remove `None` values

    return jsonify({
        "id": question.id,
        "text": question.question_statement,
        "options": options,
        "correct_option": question.correct_answer
    })


@app.route('/questions1/<int:question_id>', methods=['PUT', 'DELETE'])
def modify_question(question_id):
    question = Question.query.get(question_id)
    if not question:
        return jsonify({'error': 'Question not found'}), 404

    if request.method == 'PUT':
        try:
            data = request.get_json()
            print("Received Data:", data)  # Debugging

            if not isinstance(data, dict):
                return jsonify({'error': 'Invalid JSON format'}), 400

            if "text" not in data or "options" not in data or "correct_option" not in data:
                return jsonify({'error': 'Missing required fields'}), 400

            if not isinstance(data["options"], list) or len(data["options"]) < 2:
                return jsonify({'error': 'At least two options are required.'}), 400

            if len(data["options"]) > 4:
                return jsonify({'error': 'Maximum of 4 options allowed.'}), 400

            # Update question fields
            question.question_statement = data['text']
            options = data['options']

            # Ensure options array has correct number of elements
            question.option1 = options[0] if len(options) > 0 else None
            question.option2 = options[1] if len(options) > 1 else None
            question.option3 = options[2] if len(options) > 2 else None
            question.option4 = options[3] if len(options) > 3 else None

            # Convert correct_option index to actual answer
            correct_index = int(data.get('correct_option', -1))
            if 0 <= correct_index < len(options):
                question.correct_answer = options[correct_index]
            else:
                return jsonify({'error': 'Invalid correct_option index'}), 400

            db.session.commit()
            return jsonify({'message': 'Question updated successfully'}), 200

        except Exception as e:
            return jsonify({'error': str(e)}), 500

    elif request.method == 'DELETE':
        db.session.delete(question)
        db.session.commit()
        return jsonify({'message': 'Question deleted successfully'}), 200

@app.route('/chapters/<int:subject_id>', methods=['GET'])
def get_chapters(subject_id):
    chapters = Chapter.query.filter_by(subject_id=subject_id).all()
    return jsonify([{"id": ch.id, "name": ch.name, "description": ch.description} for ch in chapters])

@app.route('/subjects/<int:subject_id>', methods=['PUT'])
def edit_subject(subject_id):
    data = request.json
    subject = Subject.query.get(subject_id)
    if not subject:
        return jsonify({"error": "Subject not found"}), 404
    subject.name = data['name']
    subject.description = data['description']
    db.session.commit()
    return jsonify({"message": "Subject updated successfully!"})
 
@app.route('/subjects/<int:subject_id>', methods=['DELETE'])
def delete_subject(subject_id):
    subject = Subject.query.get(subject_id)
    if not subject:
        return jsonify({"error": "Subject not found"}), 404
    Chapter.query.filter_by(subject_id=subject_id).delete()
    db.session.delete(subject)
    db.session.commit()
    return jsonify({"message": "Subject and linked chapters deleted successfully!"})

 
@app.route('/chapters/<int:chapter_id>', methods=['PUT'])
def edit_chapter(chapter_id):
    data = request.json
    chapter = Chapter.query.get(chapter_id)
    if not chapter:
        return jsonify({"error": "Chapter not found"}), 404
    chapter.name = data['name']
    chapter.description = data['description']
    db.session.commit()
    return jsonify({"message": "Chapter updated successfully!"})
 
@app.route('/chapters/<int:chapter_id>', methods=['DELETE'])
def delete_chapter(chapter_id):
    chapter = Chapter.query.get(chapter_id)
    if not chapter:
        return jsonify({"error": "Chapter not found"}), 404
    db.session.delete(chapter)
    db.session.commit()
    return jsonify({"message": "Chapter deleted successfully!"})









# users


 
@app.route('/scores/<int:user_id>', methods=['GET'])
def get_user_scores(user_id):
    scores = Score.query.filter_by(user_id=user_id).all()
    result = []
    for score in scores:
        quiz = Quiz.query.get(score.quiz_id)
        result.append({
            "id": score.id,
            "num_questions": len(quiz.questions),
            "date": quiz.date_of_quiz.strftime("%d/%m/%Y"),
            "score": f"{score.total_scored}/{len(quiz.questions)}"
        })
    return jsonify(result), 200




@app.route('/quiz/<int:quiz_id>', methods=['GET'])
def get_quiz_details(quiz_id):
    quiz = Quiz.query.get(quiz_id)
    if not quiz:
        return jsonify({"error": "Quiz not found"}), 404

    return jsonify({
        "id": quiz.id,
        "subject": quiz.subject.name,
        "chapter": quiz.chapter.name,
        "num_questions": len(quiz.questions),
        "date": quiz.date_of_quiz.strftime("%d/%m/%Y"),
        "time_duration": quiz.time_duration,
        "remarks":quiz.remarks
    }), 200
    
    
@app.route('/submit-score', methods=['POST'])
def submit_quiz():
    """Handles quiz submission and records the score."""
    data = request.json
    user_id = data.get('user_id')
    quiz_id = data.get('quiz_id')
    total_scored = data.get('total_scored')

    if not all([user_id, quiz_id, total_scored is not None]):
        return jsonify({"error": "Missing required fields"}), 400

    # Save quiz attempt
    new_score = Score(user_id=user_id, quiz_id=quiz_id, total_scored=total_scored)
    db.session.add(new_score)
    db.session.commit()

    return jsonify({"message": "Quiz submitted successfully", "score_id": new_score.id})

 

@app.route('/user/<int:user_id>/quiz-attempts', methods=['GET'])
def get_quiz_attempts1(user_id):
    attempts = Score.query.filter_by(user_id=user_id).all()
    if not attempts:
        return jsonify({"message": "No quiz attempts found"}), 404

    return jsonify([{
        "quiz_id": attempt.quiz_id,
        "total_scored": attempt.total_scored,
        "timestamp": attempt.time_stamp_of_attempt,
        "date": attempt.quiz.date_of_quiz.strftime("%Y-%m-%d") 
    } for attempt in attempts])

@app.route('/quiz/<int:quiz_id>/questions', methods=['GET'])
def get_quiz_questions2(quiz_id):
    questions = Question.query.filter_by(quiz_id=quiz_id).all()
    if not questions:
        return jsonify({"message": "No questions found"}), 404
    return jsonify([q.to_dict() for q in questions])
 
@app.route("/user/<int:user_id>/quiz/<int:quiz_id>/results", methods=["GET"])
def get_quiz_results(user_id, quiz_id):
    user_attempt = Score.query.filter_by(user_id=user_id, quiz_id=quiz_id).first()
    if not user_attempt:
        return jsonify({"error": "No attempt found"}), 404

    quiz_questions = Question.query.filter_by(quiz_id=quiz_id).all()
    questions_data = []
  
    for question in quiz_questions:
        options = [question.option1, question.option2, question.option3, question.option4]
        
        # Find the correct option (if it exists)
        s = options.index(question.correct_answer) if question.correct_answer in options else -1
        
        questions_data.append({
            "id": question.id,
            "question_statement": question.question_statement,
            "option1":question.option1,
            "option2":question.option2,
            "option3":question.option3,
            "option4":question.option4,
            "correct_answer": question.correct_answer,
            'a':s
        })

    return jsonify({
        "score": user_attempt.total_scored,
        "total_questions": len(quiz_questions),
        "questions": questions_data
    })



@app.route("/save-answer", methods=["POST"])
def save_answer():
    data = request.json
    user_id = data["user_id"]
    quiz_id = data["quiz_id"]
    question_id = data["question_id"]
    selected_option = data["selected_option"]

    new_response = UserAnswer(
        user_id=user_id,
        quiz_id=quiz_id,
        question_id=question_id,
        selected_option=selected_option
    )
    db.session.add(new_response)
    db.session.commit()

    return jsonify({"message": "Answer saved successfully"}), 200


#search
 

@app.route('/search/users', methods=['GET'])
def search_users():
    query = request.args.get('q', '').strip()
    role = request.args.get('role', '').strip()
    active = request.args.get('active', '').strip()

    users_query = User.query

    if query:
        users_query = users_query.filter((User.full_name.ilike(f"%{query}%")) | (User.email.ilike(f"%{query}%")))

    if role:
        users_query = users_query.filter(User.roles.any(name=role))

    if active:
        users_query = users_query.filter(User.active == (active.lower() == "true"))

    users = users_query.all()

    return jsonify([
        {
            "id": user.id,
            "full_name": user.full_name,
            "email": user.email,
            "role": [role.name for role in user.roles],
            "active": user.active
        } for user in users
    ])


@app.route('/search/subjects', methods=['GET'])
def search_subjects():
    query = request.args.get('q', '').strip()
    description = request.args.get('description', '').strip()

    subjects_query = Subject.query

    if query:
        subjects_query = subjects_query.filter(Subject.name.ilike(f"%{query}%"))

    if description:
        subjects_query = subjects_query.filter(Subject.description.ilike(f"%{description}%"))

    subjects = subjects_query.all()

    return jsonify([
        {
            "id": subject.id,
            "name": subject.name,
            "description": subject.description
        } for subject in subjects
    ])



@app.route('/search/quizzes', methods=['GET'])
def search_quizzes():
    query = request.args.get('q', '').strip()
    subject = request.args.get('subject', '').strip()
    start_date = request.args.get('start_date', '').strip()
    end_date = request.args.get('end_date', '').strip()

    quizzes_query = Quiz.query

    if query:
        quizzes_query = quizzes_query.filter(Quiz.remarks.ilike(f"%{query}%"))

    if subject:
        quizzes_query = quizzes_query.join(Subject).filter(Subject.name.ilike(f"%{subject}%"))

    if start_date and end_date:
        quizzes_query = quizzes_query.filter(Quiz.date_of_quiz.between(start_date, end_date))

    quizzes = quizzes_query.all()

    return jsonify([
        {
            "id": quiz.id,
            "subject": quiz.subject.name if quiz.subject else "N/A",
            "chapter": quiz.chapter.name if quiz.chapter else "N/A",
            "date_of_quiz": quiz.date_of_quiz.strftime("%Y-%m-%d"),
            "remarks": quiz.remarks
        } for quiz in quizzes
    ])
     

# Route: Trigger Daily Reminder
@app.route("/send_daily_reminder", methods=["POST"])
def trigger_daily_reminder():
    task = send_daily_reminder.apply_async()
    return jsonify({"message": "Daily reminder task triggered.", "task_id": task.id})

# Route: Trigger Monthly Report
@app.route("/send_monthly_report", methods=["POST"])
def trigger_monthly_report():
    task = send_monthly_report.apply_async()
    return jsonify({"message": "Monthly report task triggered.", "task_id": task.id})
 
# Route: Check Celery Task Status
@app.route("/task_status/<task_id>", methods=["GET"])
def get_task_status(task_id):
    task_result = celery.AsyncResult(task_id)
    return jsonify({"task_id": task_id, "status": task_result.status, "result": task_result.result})
 


@app.route('/user/<int:user_id>/quiz/<int:quiz_id>/export-csv', methods=['GET'])
def export_quiz_csv(user_id, quiz_id): 
    task = export_quiz_results.apply_async(args=[user_id, quiz_id])
 
    while not task.ready():
        time.sleep(1)  # Poll every 2 seconds

    # Get CSV content
    csv_data = task.result
    if not csv_data:
        return jsonify({"error": "No quiz data found"}), 404
 
    return Response(
        csv_data,
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename=quiz_results_{user_id}_{quiz_id}.csv"}
    )
