 
from backend.models import * 

from appcreate import app1  # Import from config.py

with app1.app_context():
    datastore = app1.security.datastore
