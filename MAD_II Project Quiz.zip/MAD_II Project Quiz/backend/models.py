 
from flask_login import UserMixin# type: ignore
from datetime import datetime 
from backend.db1 import db  # Import db from app.py


class RoleMixin:
    def has_role(self, role_name):
        if role_name == 'admin':
            return getattr(self,'is_admin',False)
        return False
    
class Role(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)

user_roles = db.Table(
    'user_roles',
    db.Column('user_id', db.Integer, db.ForeignKey('user.id')),
    db.Column('role_id', db.Integer, db.ForeignKey('role.id'))
)

class User(db.Model, UserMixin, RoleMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(60), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    qualification = db.Column(db.String(100), nullable=False)
    dob = db.Column(db.Date, nullable=False)
    fs_uniquifier = db.Column(db.String(255))
    active = db.Column(db.String(10), default=True)
    roles = db.relationship('Role', secondary=user_roles, backref='users')

    def has_role(self, role_name):
        return any(role.name == role_name for role in self.roles)

    
class Chapter(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(255))
    subject_id = db.Column(db.Integer, db.ForeignKey('subject.id'), nullable=False)
    
    # Relationship with Subject (Ensuring clarity)
    subject = db.relationship('Subject', back_populates='chapters')

    # Relationship with Quiz (Avoiding conflicts)
    quizzes = db.relationship('Quiz', back_populates='chapter', cascade="all, delete-orphan")

class Subject(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(255))

    # Relationship with Chapters
    chapters = db.relationship('Chapter', back_populates='subject', cascade="all, delete-orphan")

    # Relationship with Quizzes (Ensuring no conflicts)
    quizzes = db.relationship('Quiz', back_populates='subject', cascade="all, delete-orphan")

class Quiz(db.Model):
    id = db.Column(db.Integer, primary_key=True )
    subject_id = db.Column(db.Integer, db.ForeignKey('subject.id'), nullable=False)
    chapter_id = db.Column(db.Integer, db.ForeignKey('chapter.id'), nullable=False)
    date_of_quiz = db.Column(db.DateTime, nullable=False)
    time_duration = db.Column(db.String(5), nullable=False)
    remarks = db.Column(db.String(255))

    # Relationship Fixes
    subject = db.relationship('Subject', back_populates='quizzes')
    chapter = db.relationship('Chapter', back_populates='quizzes')

class Question(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    quiz_id = db.Column(db.Integer, db.ForeignKey('quiz.id'), nullable=False)
    question_statement = db.Column(db.String(255), nullable=False)
    option1 = db.Column(db.String(100), nullable=False)
    option2 = db.Column(db.String(100), nullable=False)
    option3 = db.Column(db.String(100))
    option4 = db.Column(db.String(100))
    correct_answer = db.Column(db.String(100), nullable=False)
    quiz = db.relationship('Quiz', backref=db.backref('questions', lazy=True))

    def to_dict(self):
        return {
            'id': self.id,
            'quiz_id': self.quiz_id,
            'question_statement': self.question_statement,
            'option1': self.option1,
            'option2': self.option2,
            'option3': self.option3,
            'option4': self.option4,
            'correct_answer': self.correct_answer
        }

class Score(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    quiz_id = db.Column(db.Integer, db.ForeignKey('quiz.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    time_stamp_of_attempt = db.Column(db.String(5), nullable=False, default=datetime.utcnow)
    total_scored = db.Column(db.Integer, nullable=False)
    quiz = db.relationship('Quiz', backref=db.backref('scores', lazy=True))
    user = db.relationship('User', backref=db.backref('scores', lazy=True))
    
class UserAnswer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    quiz_id = db.Column(db.Integer, db.ForeignKey('quiz.id'), nullable=False)
    question_id = db.Column(db.Integer, db.ForeignKey('question.id'), nullable=False)
    selected_option = db.Column(db.String(100), nullable=False)
    time_answered = db.Column(db.DateTime, default=datetime.utcnow)


    # Relationships
    user = db.relationship('User', backref=db.backref('answers', lazy=True))
    quiz = db.relationship('Quiz', backref=db.backref('user_answers', lazy=True))
    question = db.relationship('Question', backref=db.backref('user_answers', lazy=True))
