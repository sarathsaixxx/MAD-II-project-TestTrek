import { createRouter, createWebHistory } from 'vue-router';
import Login from '../components/Login.vue';
import Register from '../components/Register.vue';
import Dashboard from '../components/Dashboard.vue';
import UserQuizStart from '../components/UserQuizStart.vue';
import QuizDetails from '../components/QuizDetails.vue';
import AdminLogin from '../components/AdminLogin.vue';
import AdminDashboard from '../components/AdminDashboard.vue';
import AdminQuiz from '../components/NewQuiz.vue';
import AdmAddQuestions from '../components/AdmAddQuestions.vue';
import AdmQuestionList from '../components/AdmQuestionList.vue';
import AdmEditQuestions from '../components/AdmEditQuestions.vue';
import UserQuizView from '../components/UserQuizView.vue';
import UserQuizResults from '../components/UserQuizResults.vue';
import SearchPage from '../components/SearchPage.vue';
import SummaryDetails from '../components/SummaryDetails.vue';
import UserSummaryDetails from '../components/UserSummaryDetails.vue'
import SearchUser from '../components/SearchUser.vue';
import SearchSubject from '../components/SearchSubject.vue';
import SearchQuiz from '../components/SearchQuiz.vue';


const routes = [
  { path: '/', redirect: '/login' },
  { path: '/login', component: Login },
  { path: '/register', component: Register },
  { path: '/admin', component: AdminLogin },
  {
    path: '/dashboard/:user_id/userquiz/:quiz_id',
    component: UserQuizView
  },
  {
    path: '/admdas',
    component: AdminDashboard,
    meta: { requiresAdminAuth: true }
  },
  {
    path: '/search/subject',
    component: SearchSubject,
    meta: { requiresAdminAuth: true }
  },
  {
    path: '/user/:user_id/summary/quiz/:quiz_id',
    component: UserSummaryDetails,
    meta: { requiresAuth: true }
  },
  {
    path: '/search/quiz',
    component: SearchQuiz,
    meta: { requiresAdminAuth: true }
  },
  {
    path: '/search/user',
    component: SearchUser,
    meta: { requiresAdminAuth: true }
  },
  {
    path: '/search',
    component: SearchPage,
    meta: { requiresAdminAuth: true }
  },
  {
    path: "/dashboard/:user_id/userquiz/:quiz_id/results",
    name: "UserQuizResults",
    component: UserQuizResults
  },

  {
    path: '/admqui',
    component: AdminQuiz,
    meta: { requiresAdminAuth: true }
  },
  {
    path: '/dashboard/:id',
    name: 'dashboard',
    component: Dashboard,
    beforeEnter: (to, from, next) => {
      const userId = to.params.id;
      const storedUserId = localStorage.getItem('user_id');
      const token = localStorage.getItem('token');

      if (!token || !storedUserId) {
        // Redirect to login if not authenticated
        next('/login');
      } else if (parseInt(userId) !== parseInt(storedUserId)) {
        // If the user is trying to access someone else's dashboard
        next('/login');  // Or show an error message
      } else {
        next();  // Allow access to their own dashboard
      }
    }
  },
  // Other routes 
  {
    path: "/dashboard/:user_id/userquiz/start/:quiz_id",
    name: "UserQuizStart",
    component: UserQuizStart
  },
  {
    path: '/admin/summary',
    name: 'SummaryDetails',
    component: SummaryDetails,
    props: true
  },
  {
    path: '/quiz/:quiz_id',
    name: 'QuizDetails',
    component: QuizDetails,
    props: true
  },
  {
    path: '/admadd/:quiz_id',
    name: 'AdmAddQuestions',
    component: AdmAddQuestions,
    props: true,
    meta: { requiresAdminAuth: true }
  },
  {
    path: '/admquestionlist/:quiz_id',
    name: 'AdmQuestionList',
    component: AdmQuestionList,
    props: true,
    meta: { requiresAdminAuth: true }
  },
  {
    path: '/admeditquestion/quiz/:quiz_id/question/:id',
    name: 'AdmEditQuestions',
    component: AdmEditQuestions,
    props: true,
    meta: { requiresAdminAuth: true }
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

router.beforeEach((to, from, next) => {
  const isAuthenticated = !!localStorage.getItem('token');
  const isAdminAuthenticated = !!localStorage.getItem('adminToken');

  if (to.meta.requiresAdminAuth && !isAdminAuthenticated) {
    next('/admin'); // Redirect admins to admin login
  } else if (to.meta.requiresAuth && !isAuthenticated) {
    next('/login'); // Redirect users to login
  } else {
    next(); // Allow access
  }
});




export default router;

