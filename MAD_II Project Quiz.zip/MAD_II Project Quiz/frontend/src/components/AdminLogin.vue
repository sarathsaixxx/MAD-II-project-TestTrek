<template>
  <div >
    <div class="card p-4 shadow-lg rounded-4" style="width: 350px; background-color: #1e293b; color: white;">
      <h2 class="text-center fw-bold ">Admin Login</h2>
      <p class="text-center text-white-50">Enter your admin credentials</p>
      
      <form @submit.prevent="login">
        <!-- Email Input -->
        <div class="mb-3">
          <label for="email" class="form-label">Email</label>
          <input type="email" v-model="email" class="form-control bg-dark text-white" id="email" required />
        </div>

        <!-- Password Input with Toggle -->
        <div class="mb-3 position-relative">
          <label for="password" class="form-label">Password</label>
          <div class="input-group">
            <input :type="showPassword ? 'text' : 'password'" v-model="password" class="form-control bg-dark text-white" id="password" required />
            <button type="button" class="btn btn-outline-secondary" @click="togglePassword">
              <i :class="showPassword ? 'bi bi-eye-slash' : 'bi bi-eye'"></i>
            </button>
          </div>
        </div> 
        <!-- Error Message -->
        <p v-if="errorMessage" class="text-danger text-center">{{ errorMessage }}</p>

        <!-- Login Button -->
        <button type="submit" class="btn btn-warning w-100">Login</button>
      </form>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      email: '',
      password: '',
      showPassword: false,
      errorMessage: ''
    };
  },
  methods: {
    login() {
      const adminEmail = 'aa@aa';
      const adminPassword = 'aa';

      if (this.email === adminEmail && this.password === adminPassword) {
        alert('Login successful!');
        localStorage.setItem('adminToken', 'admin-logged-in');
        this.$router.push('/admdas'); // Redirect to dashboard
      } else {
        this.errorMessage = 'Invalid Admin Credentials!';
      }
    },
    togglePassword() {
      this.showPassword = !this.showPassword;
    }
  }
};
</script>

<style scoped>


/* Background color */
.bg-light {
  background-color: #0055ff !important;
}

/* Center the login form */
.d-flex {
  min-height: 100vh;
}

/* Form control styling */
.form-control {
  border: 2px solid #334155;
}

/* Button styles */
.btn-warning {
  background-color: #ffc800;
  border: none;
}

.btn-warning:hover {
  background-color: #ffbf00;
}

/* Password input with eye icon */
.input-group .btn {
  border-left: none;
}

.input-group .form-control {
  border-right: none;
}
</style>
