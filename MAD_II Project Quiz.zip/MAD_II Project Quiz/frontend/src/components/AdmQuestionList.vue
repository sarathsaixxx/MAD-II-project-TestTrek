<template>
  <div>
    <nav class="navbar bg-primary" data-bs-theme="dark">
      <button @click="goBack" class="nav-btn">Back</button> &nbsp;
      <button @click="logout" class="logout-btn">Logout</button>
    </nav>

    <h2 class="text-lg font-bold mb-4">Quiz Questions</h2>
    
    <div v-if="questions.length > 0" class="question-list">
      <div v-for="question in questions" :key="question.id" class="question-item">
        <p><strong>Question:</strong> {{ question.text }}</p>
        <button @click="editQuestion(question.id)" class="edit-btn">Edit</button>
        <button @click="deleteQuestion(question.id)" class="delete-btn">Delete</button>
      </div>
    </div>
    <div v-else>
      <p>No questions available.</p>
    </div>

    <button @click="addQuestion" class="add-question-btn">Add New Question</button>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      questions: [],
      quiz_id: this.$route.params.quiz_id,
    };
  },
  methods: {
    async fetchQuestions() {
      try {
        const response = await axios.get(`http://127.0.0.1:5000/questions/${this.quiz_id}`);
        if (response.status === 200) {
          this.questions = response.data;
        } else {
          console.error("Error fetching questions:", response.statusText);
        }
      } catch (error) {
        console.error("API request failed:", error.message);
      }
    },
    addQuestion() {
      this.$router.push(`/admadd/${this.quiz_id}`);
    },
    editQuestion(questionId) {
      this.$router.push(`/admeditquestion/quiz/${this.quiz_id}/question/${questionId}`);
    },
    async deleteQuestion(questionId) {
      if (confirm("Are you sure you want to delete this question?")) {
        try {
          await axios.delete(`http://127.0.0.1:5000/questions1/${questionId}`);
          alert("Question deleted successfully");
          this.fetchQuestions();
        } catch (error) {
          console.error("Error deleting question:", error.message);
        }
      }
    },
    goBack() {
      this.$router.push("/admqui");
    },
    logout() {
      localStorage.removeItem("adminToken");
      this.$router.push("/admin");
    },
  },
  mounted() {
    this.fetchQuestions();
  },
};
</script>

<style scoped>
.navbar {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  background-color: #007bff;
  padding: 10px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: white;
}

.nav-btn, .logout-btn, .add-question-btn, .edit-btn, .delete-btn {
  background: white;
  color: #007bff;
  border: none;
  padding: 8px 15px;
  cursor: pointer;
  font-size: 16px;
  border-radius: 5px;
  margin-top: 20px;
}

.delete-btn {
  background: red;
  color: white;
}

.question-list {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 20px;
  padding: 20px;
}

.question-item {
  background: white;
  padding: 15px;
  border-radius: 10px;
  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
  border: 1px solid #ccc;
  min-width: 250px;
  max-width: 300px;
  text-align: center;
}

.question-item p {
  font-size: 18px;
  margin-bottom: 10px;
}

.edit-btn, .delete-btn {
  width: 100%;
  margin-top: 10px;
  font-size: 14px;
}

</style>
