<template>
  <div class="container mt-5">
    <h2>Quiz Results</h2>
    <p><strong>Quiz ID:</strong> {{ quizId }}</p>
    <p><strong>Score:</strong> {{ score }} / {{ totalQuestions }}</p>
    
    <h3>Question Breakdown</h3>
    <table class="table">
      <thead>
        <tr>
          <th>Question</th>
          <th>Options</th>
          <th>Correct Answer</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="question in questions" :key="question.id">
          <td>{{ question.question_statement }}</td>
          <td>
            1. {{ question.option1 }}<br>
            2. {{ question.option2 }}<br>
            <p v-if="question.option3">3. {{ question.option3 }}</p>
            <p v-if="question.option4">4. {{ question.option4 }}</p>
          </td>          
          <td>{{ question.a }}. {{ question.correct_answer }}</td>
          <td :class="{ correct: question.user_answer === question.correct_answer, incorrect: question.user_answer !== question.correct_answer }">
            {{ question.user_answer === question.correct_answer ? "Correct" : "Incorrect" }}
          </td>
        </tr>
      </tbody>
    </table>
    
    <button class="btn btn-primary" @click="goToDashboard">Back to Dashboard</button>&nbsp;
    <button class="btn btn-success ml-2" @click="downloadCSV">Download as CSV</button>&nbsp;
    <button class="btn btn-secondary" @click="goSummary">Summary Chart Here!!</button>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      quizId: this.$route.params.quiz_id,
      userId: this.$route.params.user_id,
      questions: [],
      score: 0,
      totalQuestions: 0,
    };
  },
  methods: {
    async fetchResults() {
      try {
        const response = await axios.get(`http://localhost:5000/user/${this.userId}/quiz/${this.quizId}/results`);
        this.questions = response.data.questions;
        this.score = response.data.score;
        this.totalQuestions = response.data.total_questions;
      } catch (error) {
        console.error("Error fetching quiz results:", error);
      }
    },
    async downloadCSV() {
      try {
        const response = await axios.get(
          `http://localhost:5000/user/${this.userId}/quiz/${this.quizId}/export-csv`,
          {},
          { responseType: "blob" } // Ensure response is treated as a file
        );

        // Create a download link
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", `quiz_results_${this.userId}_${this.quizId}.csv`);
        document.body.appendChild(link);
        link.click();
        link.remove();
      } catch (error) {
        console.error("Error exporting CSV:", error);
        alert("Error exporting CSV. Please try again later.");
      }
    },
    goToDashboard() {
      this.$router.push(`/dashboard/${this.userId}`);
    },
    goSummary(){
      this.$router.push(`/user/${this.userId}/summary/quiz/${this.quizId}`)
    }
  },
  mounted() {
    this.fetchResults();
  }
};
</script>

<style scoped>
.correct {
  color: green;
}
.incorrect {
  color: red;
}
</style>
