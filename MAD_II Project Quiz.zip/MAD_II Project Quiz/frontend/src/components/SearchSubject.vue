<template>
  <div class="container mt-4">
    <h2>Search Subjects</h2><br>

    <div class="row">
      <div class="col-md-5">
        <input v-model="query" class="form-control" placeholder="Search by name" />
      </div>
      <div class="col-md-5">
        <input v-model="description" class="form-control" placeholder="Search by description" />
      </div>
      <div class="col-md-2">
        <button @click="searchSubjects" class="btn btn-primary w-120">Search</button>
      </div>
    </div>

    <table class="table mt-4" v-if="subjects.length">
      <thead>
        <tr>
          <th>Name</th>
          <th>Description</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="subject in subjects" :key="subject.id">
          <td>{{ subject.name }}</td>
          <td>{{ subject.description }}</td>
        </tr>
      </tbody>
    </table>
  <br>
    <p v-if="!subjects.length && searched">No subjects found.</p>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      query: "",
      description: "",
      subjects: [],
      searched: false,
    };
  },
  methods: {
    async searchSubjects() {
      const params = { q: this.query, description: this.description };
      try {
        const response = await axios.get("http://127.0.0.1:5000/search/subjects", { params });
        this.subjects = response.data;
        this.searched = true;
      } catch (error) {
        console.error("Error fetching subjects", error);
      }
    },
  },
};
</script>
