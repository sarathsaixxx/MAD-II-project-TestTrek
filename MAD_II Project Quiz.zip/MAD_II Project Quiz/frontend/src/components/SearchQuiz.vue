<template>
  <div class="container mt-4">
    <h2>Search Quizzes</h2><br>

    <div class="row">
      <div class="col-md-4">
        <input v-model="query" class="form-control" placeholder="Search by remarks" />
      </div>
      <div class="col-md-3">
        <input v-model="subject" class="form-control" placeholder="Search by subject" />
      </div>
      <div class="col-md-2">
        <input type="date" v-model="start_date" class="form-control" />
      </div>
      <div class="col-md-2">
        <input type="date" v-model="end_date" class="form-control" />
      </div>
      <div class="col-md-1">
        <button @click="searchQuizzes" class="btn btn-primary w-120">Search </button>
      </div>
    </div>

    <table class="table mt-4" v-if="quizzes.length">
      <thead>
        <tr>
          <th>Subject</th>
          <th>Chapter</th>
          <th>Date</th>
          <th>Remarks</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="quiz in quizzes" :key="quiz.id">
          <td>{{ quiz.subject }}</td>
          <td>{{ quiz.chapter }}</td>
          <td>{{ quiz.date_of_quiz }}</td>
          <td>{{ quiz.remarks }}</td>
        </tr>
      </tbody>
    </table>
  <br>
    <p v-if="!quizzes.length && searched">No quizzes found.</p>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      query: "",
      subject: "",
      start_date: "",
      end_date: "",
      quizzes: [],
      searched: false,
    };
  },
  methods: {
    async searchQuizzes() {
      const params = { q: this.query, subject: this.subject, start_date: this.start_date, end_date: this.end_date };
      try {
        const response = await axios.get("http://127.0.0.1:5000/search/quizzes", { params });
        this.quizzes = response.data;
        this.searched = true;
      } catch (error) {
        console.error("Error fetching quizzes", error);
      }
    },
  },
};
</script>
