<template>
  <div>
    <nav class="navbar bg-primary" data-bs-theme="dark">
      <button @click="goBack" class="nav-btn">Back</button> &nbsp;
      <button @click="logout" class="logout-btn">Logout</button>
    </nav>

    <h2 class="text-lg font-bold mb-4">Edit Question</h2>

    <div v-if="question" class="question-form">
      <label>Question:</label>
      <input v-model="question.text" class="input-field" />

      <label>Options:</label>
      <div v-for="(option, index) in question.options" :key="index" class="option-group">
        <input v-model="question.options[index]" class="input-field" />
        <input type="radio" v-model="question.correct_option" :value="index" /> Correct
      </div>

      <button @click="updateQuestion" class="save-btn">Save Changes</button>
    </div>
    <div v-else>
      <p>Loading question details...</p>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      question: null, // Ensure it's null initially
      quiz_id:this.$route.params.quiz_id
    };
  },
  methods: {
    async fetchQuestionDetails() {
      try {
        const questionId = this.$route.params.id; // Get question ID from URL
        if (!questionId) {
          console.error("Error: questionId is undefined.");
          return;
        }

        const response = await axios.get(`http://127.0.0.1:5000/questions1/${questionId}`);
        if (response.status !== 200) {
          console.error("Failed to fetch question. Response:", response);
          return;
        }

        const data = response.data;
        if (!data.options) data.options = []; // Ensure options is always an array

        this.question = {
          id: data.id,
          text: data.text,
          options: data.options,
          correct_option: data.correct_option,
        };
      } catch (error) {
        console.error("Error fetching question:", error.response ? error.response.data : error.message);
      }
    },

    async updateQuestion() {
      try {
        if (!this.question || !this.question.id) {
          console.error("Error: Question ID is undefined.");
          return;
        }

        const payload = {
          text: this.question.text,
          options: this.question.options,
          correct_option: this.question.correct_option,
        };

        console.log("Sending data:", JSON.stringify(payload, null, 2));

        const response = await axios.put(
          `http://127.0.0.1:5000/questions1/${this.question.id}`,
          payload,
          { headers: { "Content-Type": "application/json" } }
        );

        if (response.status === 200) {
          alert("Question updated successfully");
          this.$router.push(`/admquestionlist/${this.quiz_id}`);
        } else {
          console.error("Failed to update question. Response:", response);
        }
      } catch (error) {
        console.error("Error updating question:", error.response ? error.response.data : error.message);
      }
    },

    goBack() {
      this.$router.push(`/admquestionlist/${this.quiz_id}`);
    },

    logout() {
      localStorage.removeItem("adminToken");
      this.$router.push("/admin");
    },
  },
  mounted() {
    this.fetchQuestionDetails();
  },
};
</script>


<style scoped>  
.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #007bff;
  padding: 15px 20px;
  color: white;
  position: fixed;
  width: 100%;
  top: 0;
  left: 0;
}

.btn {
  background: white;
  color: #007bff;
  border: none;
  padding: 10px 15px;
  cursor: pointer;
  font-size: 16px;
  border-radius: 5px;
  transition: 0.3s ease;
}

.btn:hover {
  background: #0056b3;
  color: white;
}

.logout {
  background: red;
  color: white;
}

.form-container {
  margin-top: 80px;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.title {
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 20px;
}

.question-form {
  background: white;
  padding: 20px;
  border-radius: 10px;
  border: 1px solid #ccc;
  width: 400px;
  display: flex;
  flex-direction: column;
}

.form-label {
  font-size: 16px;
  margin-bottom: 5px;
}

.input-field {
  width: 100%;
  padding: 8px;
  margin-bottom: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.option-group {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 8px;
}

.save-btn {
  background: #007bff;
  color: white;
  font-size: 16px;
}

.loading-text {
  font-size: 18px;
  color: gray;
} 
</style>
