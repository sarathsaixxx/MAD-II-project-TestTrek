<template>
  <div class="d-flex justify-content-center align-items-center">
    <div class="card p-4 shadow-lg rounded-4" style="width: 350px; background-color: #1e293b; color: white;">
      <h2 class="text-center fw-bold text-success">Login</h2>
      <p class="text-center text-white-50">Sign in to continue</p>
      
      <form @submit.prevent="loginUser">
        <!-- Email Input -->
        <div class="mb-3">
          <label for="email" class="form-label">Email</label>
          <input type="email" v-model="em" class="form-control bg-dark text-white" id="email" required />
        </div>

        <!-- Password Input with Toggle -->
        <div class="mb-3 position-relative">
          <label for="password" class="form-label">Password</label>
          <div class="input-group">
            <input :type="showPassword ? 'text' : 'password'" v-model="passwd" class="form-control bg-dark text-white" id="password" required />
            <button type="button" class="btn btn-outline-secondary" @click="togglePassword">
              <i :class="showPassword ? 'bi bi-eye-slash' : 'bi bi-eye'"></i>
            </button>
          </div>
        </div>

        <!-- Login Button -->
        <button type="submit" class="btn btn-success w-100">Login</button>

        <!-- Signup Link -->
        <p class="text-center mt-3 text-white-50">
          Don't have an account? <a href="/register" class="text-success fw-bold">Sign up</a>
        </p>
      </form>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      em: '',
      passwd: '',
      showPassword: false,
    };
  },
  methods: {
async loginUser() {
  try {
    const response = await fetch('http://127.0.0.1:5000/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: this.em, password: this.passwd })
    });

    const result = await response.json();

    if (response.ok) {
      alert('Login successful!');
      
      // Store the user token and user_id in localStorage
      localStorage.setItem('token', result.token);
      localStorage.setItem('user_id', result.id);  // Store user ID in localStorage

      this.$router.push(`/dashboard/${result.id}`);  // Redirect to the user's dashboard
    } else {
      alert(result.msg || 'Login failed.');
    }
  } catch (err) {
    console.error('Error:', err);
  }
},


    togglePassword() {
      this.showPassword = !this.showPassword;
    }
  }
};
</script>

<style scoped>
/* Center the login card */
.bg-light {
  background-color: #e5e7eb !important;
}

/* Input styles */
.form-control {
  border: 2px solid #334155;
}

/* Button styles */
.btn-success {
  background-color: #10b981;
  border: none;
}

.btn-success:hover {
  background-color: #059669;
}

/* Eye icon alignment */
.input-group .btn {
  border-left: none;
}

.input-group .form-control {
  border-right: none;
}
</style>
