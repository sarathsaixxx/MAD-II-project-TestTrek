<template>
  <div>
    <!-- Navigation -->
    <nav class="navbar bg-primary" data-bs-theme="dark">
      <button @click="viewDas" class="nav-btn">Dashboard</button> &nbsp; &nbsp;
      <button @click="viewSummary" class="nav-btn">Summary</button> 
      <button @click="logout" class="logout-btn">Logout</button>
    </nav>
    
    <h3>-------------------------------------------------------------------------------------------</h3>
    <h2 class="text-lg font-bold mb-2">Quiz Management</h2>

    <!-- Add/Edit Quiz Form -->
    <form @submit.prevent="handleSubmit" class="mb-4 p-4 border rounded">
      <h3 class="text-md font-semibold mb-2">{{ editingQuiz ? "Edit Quiz" : "Add Quiz" }}</h3>
      
      <label class="block">Date:
        <input v-model="quizForm.date" type="date" class="border p-2 w-full"/>
      </label>
      <br>    
      <label class="block">Time Duration (mm:ss):
        <div class="flex">
          <input v-model="minutes" type="number" min="0" class="border p-2 w-1/2" placeholder="mm" @input="updateTime"/>
          <span class="p-2">:</span>
          <input v-model="seconds" type="number" min="0" max="59" class="border p-2 w-1/2" placeholder="ss" @input="updateTime"/>
        </div>
      </label>

      <br>     
      <label class="block">Remarks:
        <input v-model="quizForm.remarks" type="text" class="border p-2 w-full"/>
      </label>
      <br>       
      <label class="block">Subject ID:
        <input v-model="quizForm.subject_id" type="number" class="border p-2 w-full"/>
      </label>
      <br>       
      <label class="block">Chapter ID:
        <input v-model="quizForm.chapter_id" type="number" class="border p-2 w-full"/>
      </label>
      <br>       
      <button type="submit" class="btn btn-success">
        {{ editingQuiz ? "Update Quiz" : "Add Quiz" }}
      </button> &nbsp;
      <button v-if="editingQuiz" @click="cancelEdit" type="button" class="btn btn-success">
        Cancel
      </button>   
    </form>

    <!-- Quiz List Table -->
    <table class="table-auto w-full border border-gray-300">
      <thead>
        <tr class="bg-gray-200">
          <th class="border px-4 py-2">ID</th>
          <th class="border px-4 py-2">Date</th>
          <th class="border px-4 py-2">Time Duration</th>
          <th class="border px-4 py-2">Remarks</th>
          <th class="border px-4 py-2">Subject ID</th>
          <th class="border px-4 py-2">Chapter ID</th>
          <th class="border px-4 py-2">Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="quiz in quizData" :key="quiz.id">
          <td class="border px-4 py-2">{{ quiz.id }}</td>
          <td class="border px-4 py-2">{{ quiz.date }}</td>
          <td class="border px-4 py-2">{{ quiz.time }}</td>
          <td class="border px-4 py-2">{{ quiz.remarks }}</td>
          <td class="border px-4 py-2">{{ quiz.subject_id }}</td>
          <td class="border px-4 py-2">{{ quiz.chapter_id }}</td>
          <td class="border px-4 py-2">
            <button @click="editQuiz(quiz)" class="bg-yellow-500 ">Edit</button> &nbsp;
            <button @click="deleteQuiz(quiz.id)" class="bg-red-500 ">Delete</button> &nbsp;
            <button @click="viewQuizDetails(quiz.id)" class="bg-blue-500 ">View</button> 
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      quizData: [],
      quizForm: {
        id: null,
        date: "",
        time: "00:00", // Initial time format
        remarks: "",
        subject_id: null,
        chapter_id: null
      },
      minutes: "00",
      seconds: "00",
      editingQuiz: false
    };
  },
  methods: {
    updateTime() {
      // Ensure valid values
      let min = parseInt(this.minutes) || 0;
      let sec = parseInt(this.seconds) || 0;

      if (sec > 59) {
        sec = 59; // Prevent > 59 seconds
      }

      // Format as "mm:ss"
      this.quizForm.time = `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
    },
    viewDas() {
      this.$router.push('/admdas');
    },

    logout() {
      localStorage.removeItem('adminToken');
      this.$router.push('/admin');
    },

    async fetchQuizzes() {
      try {
        const response = await axios.get("http://127.0.0.1:5000/quizzes");
        if (response.status === 200) {
          this.quizData = response.data;
        } else {
          console.error("Error fetching quizzes:", response.statusText);
        }
      } catch (error) {
        console.error("API request failed:", error.message);
      }
    },
    
    async addQuiz() {
      try {
        const response = await axios.post("http://127.0.0.1:5000/quizzes", this.quizForm);
        if (response.status === 201) {
          this.fetchQuizzes();
          this.resetForm();
        }
      } catch (error) {
        console.error("Failed to add quiz:", error.message);
      }
    },

    async updateQuiz() {
      try {
        const response = await axios.put(`http://127.0.0.1:5000/quizzes/${this.quizForm.id}`, this.quizForm);
        if (response.status === 200) {
          this.fetchQuizzes();
          this.resetForm();
          this.editingQuiz = false;
        }
      } catch (error) {
        console.error("Failed to update quiz:", error.message);
      }
    },

    async deleteQuiz(id) {
      if (!confirm("Are you sure you want to delete this quiz?")) return;
      try {
        const response = await axios.delete(`http://127.0.0.1:5000/quizzes/${id}`);
        if (response.status === 200) {
          this.fetchQuizzes();
        }
      } catch (error) {
        console.error("Failed to delete quiz:", error.message);
      }
    },

    editQuiz(quiz) {
      this.quizForm = { ...quiz };
      this.editingQuiz = true;
      const [min, sec] = quiz.time.split(":");
      this.minutes = min;
      this.seconds = sec;
    },

    handleSubmit() {
      if (this.editingQuiz) {
        this.updateQuiz();
      } else {
        this.addQuiz();
      }
    },

    cancelEdit() {
      this.resetForm();
      this.editingQuiz = false;
    },

    resetForm() {
      this.quizForm = {
        id: null,
        date: "",
        time: "00:00", // Reset time to "00:00"
        remarks: "",
        subject_id: null,
        chapter_id: null
      };
      this.minutes = "00";
      this.seconds = "00";
    },

    viewQuizDetails(quizId) {
      this.$router.push(`/quiz/${quizId}`);
    }
  },

  mounted() {
    this.fetchQuizzes();
  }
};
</script> 
 
 

<style scoped>



/* Form Styling */
form {
    max-width: 400px;
    margin: auto;
    padding: 20px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Label Styling */
label {
    font-weight: bold;
    display: block;
    margin-bottom: 5px;
}

/* Input Styling */
input {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px; /* Adds space between inputs */
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
}

/* Button Styling */
button {
    padding: 10px 15px;
    font-size: 16px;
    border-radius: 5px;
    border: none;
    cursor: pointer;
}

.btn-success {
    background-color: #28a745;
    color: white;
}

.btn-success:hover {
    background-color: #218838;
}

/* Centered Form */
form {
    max-width: 1050px; /* Increased width for better alignment */
    margin: auto;
    padding: 20px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Table Styling */
table {
    max-width: 600px; /* Matches form width */
    margin: auto; /* Centers the table */
    border-collapse: collapse;
    width: 100%; /* Ensures it fits container */
}
   




/* Navbar Styling */
.navbar {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    background-color: #007bff;
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: white;
}

/* Align Home and Summary buttons to the left */
.nav-buttons {
    display: flex;
    gap: 10px;
}

/* Logout button aligned to the right */
.logout-btn {
    background: red;
    color: white;
    border: none;
    padding: 8px 15px;
    cursor: pointer;
    font-size: 16px;
    border-radius: 5px;
    margin-left: auto; /* Pushes logout button to the right */
}

/* Button Styling */
.nav-btn {
    background: white;
    color: #007bff;
    border: none;
    padding: 8px 15px;
    cursor: pointer;
    font-size: 16px;
    border-radius: 5px;
} 
</style>