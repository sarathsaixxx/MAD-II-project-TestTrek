<template>
  <div>
    <nav class="navbar bg-primary">
      <button @click="goBack" class="nav-btn">Back</button>
      <button @click="logout" class="logout-btn">Logout</button>
    </nav>
    
    <h2>Add Question</h2> <br>
    <form @submit.prevent="addQuestion">
      <label>Question:</label><br>
      <input v-model="question.text" required />
      <br>
      <label>Options:</label> <br>
      <div v-for="(option, index) in question.options" :key="index">
        <input v-model="question.options[index]" required />
        <input type="radio" name="correctOption" :value="index" v-model="question.correctOption" /> Correct
        <button type="button" class="btn btn-danger" @click="removeOption(index)">Remove</button>
      </div><br>
      <button type="button" class="btn btn-primary" @click="addOption" :disabled="question.options.length >= 4">Add Option</button> &nbsp;
      <button type="submit" class="btn btn-success">Submit</button>
    </form>
  </div>
</template>

<script>
import axios from "axios";
export default {
  data() {
    return {
      question: { text: "", options: ["", ""], correctOption: 0 },  
      quiz_id: this.$route.params.quiz_id,
    };
  },
  methods: {
    async addQuestion() {
      try {
        console.log("Sending data:", this.question);

        const response = await axios.post(`http://127.0.0.1:5000/questions/${this.quiz_id}`, {
          question_statement: this.question.text,
          options: this.question.options,  
          correct_answer: this.question.options[this.question.correctOption], 
        });

        console.log("Server response:", response.data);
        this.$router.push(`/admquestionlist/${this.quiz_id}`);
      } catch (error) {
        console.error("Error adding question", error.response ? error.response.data : error.message);
      }
    },
    addOption() {
      if (this.question.options.length < 4) {
        this.question.options.push("");
      }
    },
    removeOption(index) {
      if (this.question.options.length > 2) {
        this.question.options.splice(index, 1);
      } else {
        alert("At least two options are required.");
      }
    },
    goBack() {
      this.$router.push(`/quiz/${this.quiz_id}`);
    },
    logout() {
      localStorage.removeItem("adminToken");
      this.$router.push("/admin");
    },
  },
};
</script>


<style scoped>




/* Navbar Styling */
.navbar {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    background-color: #007bff;
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: white;
}

/* Align Home and Summary buttons to the left */
.nav-buttons {
    display: flex;
    gap: 10px;
}

/* Logout button aligned to the right */
.logout-btn {
    background: red;
    color: white;
    border: none;
    padding: 8px 15px;
    cursor: pointer;
    font-size: 16px;
    border-radius: 5px;
    margin-left: auto; /* Pushes logout button to the right */
}

/* Button Styling */
.nav-btn {
    background: white;
    color: #007bff;
    border: none;
    padding: 8px 15px;
    cursor: pointer;
    font-size: 16px;
    border-radius: 5px;
} 
</style>
