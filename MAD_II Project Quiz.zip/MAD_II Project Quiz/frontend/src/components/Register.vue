<template>
<div class="container mt-5">
  <div class="card shadow p-4">
    <h2 class="text-center mb-4">Register</h2>
    <form @submit.prevent="registerUser">
      <div class="row mb-3">
        <div class="col-md-6">
          <label for="email" class="form-label">Email</label>
          <input 
            type="email" 
            v-model="em" 
            class="form-control" 
            id="email" 
            placeholder="Enter your email" 
            required 
          />
        </div>
        <div class="col-md-6">
          <label for="password" class="form-label">Password</label>
          <input 
            type="password" 
            v-model="passwd" 
            class="form-control" 
            id="password" 
            placeholder="Choose a secure password" 
            required 
          />
        </div>
      </div>
      <div class="row mb-3">
        <div class="col-md-6">
          <label for="fullName" class="form-label">Full Name</label>
          <input 
            type="text" 
            v-model="fN" 
            class="form-control" 
            id="fullName" 
            placeholder="Enter your full name" 
            required 
          />
        </div>
        <div class="col-md-6">
          <label for="qualification" class="form-label">Qualification</label>
          <input 
            type="text" 
            v-model="qualIFn" 
            class="form-control" 
            id="qualification" 
            placeholder="Your highest qualification" 
            required 
          />
        </div>
      </div>
      <div class="mb-3">
        <label for="dob" class="form-label">Date of Birth</label>
        <input 
          type="date" 
          v-model="dOb" 
          class="form-control" 
          id="dob" 
          required 
        />
      </div>
      <button type="submit" class="btn btn-primary w-100">Register</button>
    </form>
  </div>
</div>

</template>

<script>
export default {
  data() {
    return {
      em: '',
      passwd: '',
      fN: '',
      qualIFn: '',
      dOb: ''
    };
  },
  methods: {
    async registerUser() {
      try {
        const response = await fetch('http://127.0.0.1:5000/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: this.em,
            password: this.passwd,
            full_name: this.fN,
            qual: this.qualIFn,
            dob: this.dOb
          })
        });
        const res = await response.json();
        if (response.ok) {
          alert('Registration successful!');
          this.$router.push('/login');
        } else {
          alert(res.msg || 'Registration failed.');
        }
      } catch (err) {
        console.error('Error:', err);
      }
    }
  }
};
</script>
<style scoped>
html, body {
  height: 100%; /* Ensure the container takes up the full viewport height */
  margin: 0;
  display: flex;
  justify-content: center; /* Horizontally center the content */
  align-items: center; /* Vertically center the content */
  background-color: #f8f9fa; /* Light background for contrast */
}

.container {
  max-width: 600px; /* Limit the width of the form */
  width: 90%; /* Ensure responsiveness on smaller screens */
  background: #ffffff; /* White background for the form card */
  border-radius: 10px; /* Rounded corners */
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Subtle shadow for depth */
  padding: 2rem; /* Add padding inside the card */
  text-align: left; /* Align form content to the left */
}


.card h2 {
  text-align: center; /* Center the heading */
  font-size: 1.8rem; /* Slightly larger heading */
  margin-bottom: 1.5rem; /* Add space below the heading */
}

.form-label {
  font-weight: 500; /* Slightly bold labels */
}

.form-control {
  margin-bottom: 1rem; /* Add space between form fields */
  padding: 10px; /* Ensure comfortable input space */
  border-radius: 5px; /* Rounded corners for input fields */
}

.form-control:focus {
  outline: none;
  box-shadow: 0 0 5px rgba(0, 123, 255, 0.5); /* Highlight effect on focus */
  border-color: #007bff;
}

.btn-primary {
  width: 100%; /* Full-width button */
  padding: 0.75rem; /* Increase padding for better click area */
  font-size: 1rem; /* Uniform button font size */
  border-radius: 5px; /* Rounded button corners */
  transition: background-color 0.2s ease, box-shadow 0.2s ease; /* Smooth transition */
}

.btn-primary:hover {
  background-color: #0056b3; /* Slightly darker blue on hover */
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2); /* Add shadow on hover */
}



</style>