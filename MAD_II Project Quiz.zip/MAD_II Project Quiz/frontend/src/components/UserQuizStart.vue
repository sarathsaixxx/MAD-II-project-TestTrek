<template>
  <div>
    <!-- Navbar -->
    <nav class="navbar">
      <div class="nav-buttons">
        <button class="nav-btn" @click="goToDashboard">Home</button>
        <button class="nav-btn" @click="goToSummary">Summary</button>
      </div>
      <button class="logout-btn" @click="logout">Logout</button>
    </nav>

    <!-- Main Quiz Container -->
    <div class="container">
      <h2>Quiz Session</h2>

      <!-- Page Expired Message -->
      <div v-if="pageExpired" class="expired-message">
        <h3>This quiz session has expired.</h3>
        <button class="btn-primary" @click="goToDashboard">Back to Dashboard</button>
      </div>

      <!-- Timer -->
      <div v-if="!quizCompleted && !pageExpired" class="timer">
        <h3>Time Left: {{ formattedTime }}</h3>
      </div>

      <!-- Quiz Question -->
      <div v-if="!quizCompleted && !pageExpired && currentQuestion" class="quiz-box">
        <h4>Q{{ currentIndex + 1 }}/{{ questions.length }}: {{ currentQuestion.question_statement }}</h4>
        <ul class="options-list">
          <li v-for="(option, index) in options" :key="index">
            <input 
              type="radio" 
              :id="'option' + index" 
              :value="option" 
              v-model="selectedAnswer" 
              @change="saveAnswer(option)"
            />
            <label :for="'option' + index">{{ option }}</label>
          </li>
        </ul>
        <button class="btn-secondary" @click="nextQuestion" v-if="currentIndex < questions.length - 1">Next</button>
        <button class="btn-success" @click="submitQuiz" v-else-if="!quizCompleted">Submit</button> 
      </div>

      <!-- Quiz Completed -->
      <div v-if="quizCompleted" class="quiz-completed">
        <h3>Quiz Completed!</h3>
        <p>Your Score: {{ score }} / {{ questions.length }}</p>
        <button class="btn-primary" @click="goToDashboard">Back to Dashboard</button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      quizId: this.$route.params.quiz_id,
      userId: localStorage.getItem("user_id"),
      questions: [],
      currentIndex: 0,
      selectedAnswer: "",
      score: 0,
      timer: 0,
      timerInterval: null,
      quizCompleted: false,
      pageExpired: false
    };
  },
  computed: {
    currentQuestion() {
      return this.questions[this.currentIndex];
    },
    options() {
      return this.currentQuestion
        ? [this.currentQuestion.option1, this.currentQuestion.option2, this.currentQuestion.option3, this.currentQuestion.option4].filter(Boolean)
        : [];
    },
    formattedTime() {
      let minutes = Math.floor(this.timer / 60);
      let seconds = this.timer % 60;
      return `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
    }
  },
  methods: {
    async fetchQuestions() {
      try {
        const response = await axios.get(`http://localhost:5000/quiz/${this.quizId}/questions`);
        this.questions = response.data;
        const quizDetails = await axios.get(`http://localhost:5000/quiz/${this.quizId}`);

        if (localStorage.getItem(`quiz_completed_${this.userId}_${this.quizId}`)) {
          this.pageExpired = true;
          return;
        }

        const savedTime = localStorage.getItem(`quiz_timer_${this.userId}_${this.quizId}`);
        this.timer = savedTime ? parseInt(savedTime) : this.convertTimeToSeconds(quizDetails.data.time_duration);
        this.startTimer();
      } catch (error) {
        console.error("Error fetching questions:", error);
      }
    },

    async saveAnswer(option) {
      try {
        await axios.post("http://localhost:5000/save-answer", {
          user_id: this.userId,
          quiz_id: this.quizId,
          question_id: this.currentQuestion.id,
          selected_option: option
        });
      } catch (error) {
        console.error("Error saving answer:", error);
      }
    },

    convertTimeToSeconds(timeStr) {
      const [minutes, seconds] = timeStr.split(":").map(Number);
      return minutes * 60 + seconds;
    },

    startTimer() {
      this.timerInterval = setInterval(() => {
        if (this.timer > 0) {
          this.timer--;
          localStorage.setItem(`quiz_timer_${this.userId}_${this.quizId}`, this.timer);
        } else {
          this.handleTimeUp();
        }
      }, 1000);
    },

    handleTimeUp() {
      clearInterval(this.timerInterval);
      localStorage.setItem(`quiz_completed_${this.userId}_${this.quizId}`, "true");
      alert("Time's up! Redirecting to dashboard.");
      this.goToDashboard();
    },

    nextQuestion() {
      if (this.selectedAnswer === this.currentQuestion.correct_answer) {
        this.score++;
      }
      this.selectedAnswer = "";
      this.currentIndex++;
    },

    async submitQuiz() {
      clearInterval(this.timerInterval);
      this.quizCompleted = true;

      localStorage.setItem(`quiz_completed_${this.userId}_${this.quizId}`, "true");

      if (this.selectedAnswer === this.currentQuestion.correct_answer) {
        this.score++;
      }

      try {
        await axios.post("http://localhost:5000/submit-score", {
          user_id: this.userId,
          quiz_id: this.quizId,
          total_scored: this.score
        });

        localStorage.removeItem(`quiz_timer_${this.userId}_${this.quizId}`);
      } catch (error) {
        console.error("Error submitting score:", error);
      }
    },

    goToDashboard() {
      this.$router.push(`/dashboard/${this.userId}`);
    },
    goToSummary() {
      this.$router.push(`/user/${this.userId}/summary/quiz/${this.quizId}`);
    },
    logout() {
      localStorage.removeItem("user_id");
      this.$router.push("/login");
    }
  },

  mounted() {
    this.quizId = this.$route.params.quiz_id;
    if (this.quizId) {
      this.fetchQuestions();
    }
  }
};
</script>

<style scoped>
/* General Styles */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 0;
}

/* Navbar */
.navbar {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    background-color: #007bff;
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: white;
}

.nav-buttons {
    display: flex;
    gap: 10px;
}

.nav-btn, .logout-btn {
    border: none;
    padding: 10px 15px;
    font-size: 16px;
    cursor: pointer;
    border-radius: 5px;
    transition: all 0.3s ease;
}

.nav-btn {
    background: white;
    color: #007bff;
}

.nav-btn:hover {
    background: #0056b3;
    color: white;
}

.logout-btn {
    background: red;
    color: white;
}

.logout-btn:hover {
    background: darkred;
}

/* Timer */
.timer {
    font-size: 20px;
    color: red;
    font-weight: bold;
    margin: 20px 0;
}

/* Quiz Box */
.quiz-box {
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

/* Quiz Completed */
.quiz-completed {
    text-align: center;
}

/* Button Styling */
.btn-primary, .btn-secondary, .btn-success {
    padding: 10px 15px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
}

.btn-primary {
    background: #007bff;
    color: white;
}

.btn-secondary {
    background: #28a745;
    color: white;
}

.btn-success {
    background: #17a2b8;
    color: white;
}
</style>
