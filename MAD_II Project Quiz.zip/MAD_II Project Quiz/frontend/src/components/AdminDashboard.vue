<template>
  <div class="container mt-5">
     <h2>Admin Dashboard</h2>
    
    <!-- Navigation -->
        <nav class="navbar bg-primary" data-bs-theme="dark">
      <button @click="viewQuiz" class="nav-btn">Quiz</button> &nbsp; &nbsp;
      <button @click="viewSummary" class="nav-btn">Summary</button> &nbsp; &nbsp;
      <button @click="search" class="nav-btn">Search All</button> 
      <button @click="logout" class="logout-btn">Logout</button>
    </nav>
     <!-- Add/Edit Subject -->
    <div>
      <h3>{{ isEditingSubject ? "Edit Subject" : "Add Subject" }}</h3>
      <input v-model="subjectName" placeholder="Subject Name" required> &nbsp;
      <input v-model="subjectDescription" placeholder="Description"> &nbsp;
      <button @click="isEditingSubject ? updateSubject() : addSubject()">
        {{ isEditingSubject ? "Update Subject" : "Add Subject" }}
      </button>
    </div>

    <!-- Subject List -->
    <div>
    <table class="table-auto w-full border border-gray-300">
      <thead>
        <tr class="bg-gray-200">
          <th class="border px-4 py-2">Subject Name</th>
          <th class="border px-4 py-2">Description</th> 
          <th class="border px-4 py-2">Options</th> 
        </tr>
      </thead>
      <tbody>
        <tr v-for="subject in subjects" :key="subject.id">
          <td class="border px-4 py-2">{{ subject.name }}</td>
          <td class="border px-4 py-2">{{ subject.description }}</td> 
          <td class="border px-4 py-2">
          <button @click="editSubject(subject)">Edit</button>&nbsp;
          <button @click="deleteSubject(subject.id)">Delete</button>&nbsp;
          <button @click="selectSubject(subject.id)">View Chapters</button>
          </td>
        </tr>
      </tbody>
    </table> 
    </div>

    
    <!-- Add/Edit Chapter -->
    <div v-if="selectedSubject">
      <h3>{{ isEditingChapter ? "Edit Chapter" : "Add Chapter" }} to "{{ selectedSubjectName }}" Subject</h3>
      <input v-model="chapterName" placeholder="Chapter Name" required>&nbsp;
      <input v-model="chapterDescription" placeholder="Description">&nbsp;
      <button @click="isEditingChapter ? updateChapter() : addChapter()">
        {{ isEditingChapter ? "Update Chapter" : "Add Chapter" }}
      </button>
    </div>

    <!-- Chapter List -->
<div v-for="chapter in chapters" :key="chapter.id">
  <table class="table-auto w-full border border-gray-300">
    <thead>
      <tr class="bg-gray-200">
        <th class="border px-4 py-2">Chapter Name</th>
        <th class="border px-4 py-2">Date</th>
        <th class="border px-4 py-2">Chapter</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td class="border px-4 py-2">{{ chapter.name }}</td>
        <td class="border px-4 py-2">{{ chapter.description }}</td>
        <td class="border px-4 py-2">
          <button @click="editChapter(chapter)">Edit</button>&nbsp;
          <button @click="deleteChapter(chapter.id)">Delete</button>&nbsp;
        </td>
      </tr>
    </tbody>
  </table>
</div>

  </div> 
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      subjectName: '',
      subjectDescription: '',
      subjects: [],
      selectedSubject: null,
      selectedSubjectName: '',
      chapterName: '',
      chapterDescription: '',
      chapters: [],
      isEditingSubject: false,
      isEditingChapter: false,
      editingSubjectId: null,
      editingChapterId: null
    };
  },
  methods: {
    async viewSubjects() {
      const response = await axios.get('http://127.0.0.1:5000/subjects');
      this.subjects = response.data;
    },
    
    async addSubject() {
      if (!this.subjectName.trim()) {
        this.subjectError = "Subject name is required.";
        return;
      }
      await axios.post('http://127.0.0.1:5000/subjects', {
        name: this.subjectName,
        description: this.subjectDescription
      });
      this.subjectName = '';
      this.subjectDescription = '';
      this.viewSubjects();
    },

    editSubject(subject) {
      this.subjectName = subject.name;
      this.subjectDescription = subject.description;
      this.editingSubjectId = subject.id;
      this.isEditingSubject = true;
    },

    async updateSubject() {
      if (!this.subjectName.trim()) {
        this.subjectError = "Subject name is required.";
        return;
      }
      await axios.put(`http://127.0.0.1:5000/subjects/${this.editingSubjectId}`, {
        name: this.subjectName,
        description: this.subjectDescription
      });
      this.subjectName = '';
      this.subjectDescription = '';
      this.isEditingSubject = false;
      this.editingSubjectId = null;
      this.viewSubjects();
    },

    async deleteSubject(subjectId) {
      const confirmDelete = confirm("Are you sure you want to delete this subject? All linked chapters will also be deleted!");
      
      if (confirmDelete) {
        await axios.delete(`http://127.0.0.1:5000/subjects/${subjectId}`);
        this.viewSubjects();
        this.chapters = [];  // Clear chapters if the selected subject is deleted
      }
    },

    async selectSubject(subjectId) {
      this.selectedSubject = subjectId;
      this.selectedSubjectName = this.subjects.find(sub => sub.id === subjectId).name;
      this.viewChapters(subjectId);
    },

    async viewChapters(subjectId) {
      const response = await axios.get(`http://127.0.0.1:5000/chapters/${subjectId}`);
      this.chapters = response.data;
    },

    async addChapter() { 
      if (!this.chapterName.trim()) {
        this.chapterError = "Chapter name is required.";
        return;
      }
      await axios.post('http://127.0.0.1:5000/chapters', {
        name: this.chapterName,
        description: this.chapterDescription,
        subject_id: this.selectedSubject
      });
      this.chapterName = '';
      this.chapterDescription = '';
      this.viewChapters(this.selectedSubject);
    },

    editChapter(chapter) {
      this.chapterName = chapter.name;
      this.chapterDescription = chapter.description;
      this.editingChapterId = chapter.id;
      this.isEditingChapter = true;
    },

    async updateChapter() {
        if (!this.chapterName.trim()) {
        this.chapterError = "Chapter name is required.";
        return;
      }
      await axios.put(`http://127.0.0.1:5000/chapters/${this.editingChapterId}`, {
        name: this.chapterName,
        description: this.chapterDescription
      });
      this.chapterName = '';
      this.chapterDescription = '';
      this.isEditingChapter = false;
      this.editingChapterId = null;
      this.viewChapters(this.selectedSubject);
    },
 
    async deleteChapter(chapterId) {
      const confirmDelete = confirm("Are you sure you want to delete this chapter?");
      
      if (confirmDelete) {
        await axios.delete(`http://127.0.0.1:5000/chapters/${chapterId}`);
        this.viewChapters(this.selectedSubject);
      }
    },
 
    logout() {
      localStorage.removeItem('adminToken');
      this.$router.push('/admin');
    },
    viewQuiz() { 
      this.$router.push('/admqui');
    },
    viewSummary() { 
      this.$router.push('/admin/summary');
    },
    search(){
      this.$router.push('/search');
    },
  },
  mounted() {
    this.viewSubjects();
  }
};
</script>
<style scoped>  
 






/* Navbar Styling */

.navbar {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    background-color: #007bff;
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: white;
}

/* Align Home and Summary buttons to the left */
.nav-buttons {
    display: flex;
    gap: 10px;
}

/* Logout button aligned to the right */
.logout-btn {
    background: red;
    color: white;
    border: none;
    padding: 8px 15px;
    cursor: pointer;
    font-size: 16px;
    border-radius: 5px;
    margin-left: auto; /* Pushes logout button to the right */
}

/* Button Styling */
.nav-btn {
    background: white;
    color: #007bff;
    border: none;
    padding: 8px 15px;
    cursor: pointer;
    font-size: 16px;
    border-radius: 5px;
}

</style>