<template>
  <div class="container mt-5">
    <h2>User Quiz Summary</h2>
    <p><strong>Quiz ID:</strong> {{ quizId }}</p>
    <p><strong>User ID:</strong> {{ userId }}</p>

    <div v-if="chartUrl">
      <h3>Score Visualization</h3>
      <img :src="chartUrl" alt="User Score Chart" class="chart-image"/>
    </div>
    <div v-else>
      <p>Loading chart...</p>
    </div>

    <button class="btn btn-primary mt-3" @click="goBack">Back to Results</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      quizId: this.$route.params.quiz_id,
      userId: this.$route.params.user_id,
      chartUrl: null
    };
  },
  methods: {
    fetchChart() {
      this.chartUrl = `http://127.0.0.1:5000/user/${this.userId}/summary/quiz/${this.quizId}?timestamp=${new Date().getTime()}`;
    },
    goBack() {
      this.$router.push(`/dashboard/${this.userId}/userquiz/${this.quizId}/results`);
    }
  },
  mounted() {
    this.fetchChart();
  }
};
</script>

<style scoped>
.chart-image {
  width: 100%;
  max-width: 600px;
  border: 1px solid #ccc;
  border-radius: 10px;
  padding: 10px;
  box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.2);
}
</style>
