<template>
  <div class="container mt-5">
    <h2>Search Which ??</h2><br>
    
    <!-- Navigation -->
    <nav class="navbar bg-primary" data-bs-theme="dark">
      <!-- Left aligned buttons: Summary -->
      <div class="nav-buttons">
        <button @click="viewSummary" class="nav-btn">Summary</button>
      </div>

      <!-- Logout button -->
      <button @click="logout" class="logout-btn">Logout</button>
    </nav>
    <button @click="searchU" class="btn btn-outline-primary me-2">Search User</button> &nbsp;
    <button @click="searchS" class="btn btn-outline-primary me-2">Search Subject</button> &nbsp; 
    <button @click="searchQ" class="btn btn-outline-primary">Search Quiz</button>    
  </div>
</template>

<script>
export default {
  methods: {
    searchU(){
        this.$router.push('/search/user');
    },
    searchS(){
        this.$router.push('/search/subject');
    },
    searchQ(){
        this.$router.push('/search/quiz');
    },
    logout() {
      localStorage.removeItem('adminToken');
      this.$router.push('/admin');
    },
    
    viewSummary() {
      console.log('Viewing summary...');
    }
  }
};
</script>

<style scoped>   

/* Navbar Styling */

.navbar {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    background-color: #007bff;
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: white;
}

/* Align Home and Summary buttons to the left */
.nav-buttons {
    display: flex;
    gap: 10px;
}

/* Logout button aligned to the right */
.logout-btn {
    background: red;
    color: white;
    border: none;
    padding: 8px 15px;
    cursor: pointer;
    font-size: 16px;
    border-radius: 5px;
    margin-left: auto; /* Pushes logout button to the right */
}

/* Button Styling */
.nav-btn {
    background: white;
    color: #007bff;
    border: none;
    padding: 8px 15px;
    cursor: pointer;
    font-size: 16px;
    border-radius: 5px;
}

</style>