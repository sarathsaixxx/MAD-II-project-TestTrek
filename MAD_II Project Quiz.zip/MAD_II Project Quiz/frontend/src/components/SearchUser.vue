<template>
  <div class="container mt-4">
    <h2>Search Users</h2><br>
    
    <div class="row">
      <div class="col-md-9">
        <input v-model="query" class="form-control" placeholder="Search by name or email" />
      </div> 
      <div class="col-md-3">
        <button @click="searchUsers" class="btn btn-primary w-120">Search</button>
      </div>
    </div>

    <table class="table mt-4" v-if="users.length">
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th> 
          <th>Active</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="user in users" :key="user.id">
          <td>{{ user.full_name }}</td>
          <td>{{ user.email }}</td> 
          <td>{{ user.active ? "Yes" : "No" }}</td>
        </tr>
      </tbody>
    </table>
  <br>
    <p v-if="!users.length && searched">No users found.</p>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      query: "",
      role: "",
      active: "",
      users: [],
      searched: false,
    };
  },
  methods: {
    async searchUsers() {
      const params = { q: this.query, role: this.role, active: this.active };
      try {
        const response = await axios.get("http://127.0.0.1:5000/search/users", { params });
        this.users = response.data;
        this.searched = true;
      } catch (error) {
        console.error("Error fetching users", error);
      }
    },
  },
};
</script>
