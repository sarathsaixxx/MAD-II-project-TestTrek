<template>
  <div>
    <h2>Admin Dashboard - Summary Charts</h2>
    <div class="chart-container">
      <div>
        <h3>User Participation</h3>
        <img :src="userParticipationUrl" alt="User Participation Chart" />
      </div>
      <div>
        <h3>Quiz Performance</h3>
        <img :src="quizPerformanceUrl" alt="Quiz Performance Chart" />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      userParticipationUrl: "http://127.0.0.1:5000/admin/chart/user_participation",
      quizPerformanceUrl: "http://127.0.0.1:5000/admin/chart/quiz_performance",
    };
  }
};
</script>

<style>
.chart-container {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
}
.chart-container div {
  flex: 1;
  text-align: center;
}
img {
  max-width: 100%;
  height: auto;
  border: 1px solid #ccc;
  padding: 10px;
  border-radius: 8px;
}
</style>
