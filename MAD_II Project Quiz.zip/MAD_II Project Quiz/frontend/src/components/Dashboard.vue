<template>
  <div class="container mt-5">
    <nav class="navbar bg-primary" data-bs-theme="dark">
      <button @click="goBack" class="nav-btn">Scores</button> &nbsp;
      <button @click="userSummary" class="nav-btn">Summary</button> 
      <button @click="logout" class="logout-btn">Logout</button> 
    </nav>
    <h3>Upcoming Quizzes</h3>
    <table class="table">
      <thead>
        <tr>
          <th>ID</th>
          <th>No. of Questions</th>
          <th>Date</th>
          <th>Duration (hh:mm)</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="quiz in filteredQuizzes" :key="quiz.id">
          <td>{{ quiz.id }}</td>
          <td>{{ quiz.num_questions  }}</td>
          <td>{{ quiz.date }}</td>
          <td>{{ quiz.time }}</td>
          <td>
            <button class="btn btn-primary" @click="viewQuiz(quiz.id)">View</button>
            
            <button 
              class="btn btn-success" 
              @click="startQuiz(quiz.id)" 
              :disabled="hasAttemptedQuiz(quiz.id)">
              Start
            </button>

            <button 
              class="btn btn-info" 
              v-if="hasAttemptedQuiz(quiz.id)" 
              @click="viewResults(quiz.id)">
              View Results
            </button>
  
          </td>

        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return { 
    quizzes: [],
    searchQuery: '',
    user: {},
    user_id: this.$route.params.id,
    previousAttempts: [] // Ensure it's always an array 

    };
  },
  computed: {
    filteredQuizzes() {
      return this.quizzes.filter(quiz =>
        quiz.date.includes(this.searchQuery) ||
        quiz.num_questions.toString().includes(this.searchQuery)
      );
    }
  },
  methods: {
    
    async fetchQuizzes() {
      try {
        const response = await axios.get('http://localhost:5000/quizzes1');
        this.quizzes = response.data;
      } catch (error) {
        console.error('Error fetching quizzes:', error);
      }
    }, 
    async fetchUser() {
      try {
        const response = await axios.get(`http://localhost:5000/user/${this.user_id}`, { withCredentials: true }); 
      } catch (error) {
        console.error('Error fetching user:', error);
      }
    },
    logout() {
      axios.post('http://localhost:5000/logout', {}, { withCredentials: true })
        .then(() => {
          console.log("Logout successful");  // Debugging
          localStorage.removeItem('token');
          this.$router.push('/login');
        })
        .catch(error => {
          console.error('Logout error:', error);
          alert('Logout failed! Check the console for details.');
        });
    },
    viewQuiz(quiz_id) {
      this.$router.push(`/dashboard/${this.user_id}/userquiz/${quiz_id}`);
    },
  startQuiz(quiz_id) {
    if (!quiz_id) {
      console.error("Quiz ID is missing");
      return;
    }
    this.$router.push(`/dashboard/${this.user_id}/userquiz/start/${quiz_id}`);
  },
  async fetchPreviousAttempts() {
    try {
      const response = await axios.get(`http://localhost:5000/user/${this.user_id}/quiz-attempts`);
      this.previousAttempts = response.data;
    } catch (error) {
      console.error("Error fetching previous attempts:", error);
    }
  },
  
  hasAttemptedQuiz(quiz_id) {
    return Array.isArray(this.previousAttempts) && 
          this.previousAttempts.some(attempt => attempt.quiz_id === quiz_id);
  },


  viewResults(quiz_id) {
    this.$router.push(`/dashboard/${this.user_id}/userquiz/${quiz_id}/results`);
  },
  userSummary(){
    this.$router.push(`/user/summary`);
  }
},

mounted() {
  this.fetchQuizzes();
  this.fetchUser();
  this.fetchPreviousAttempts(); // Fetch attempts on page load
}
};
</script>

<style>

/* General Styles */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 0;
}

/* Navbar */
.navbar {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    background-color: #007bff;
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: white;
}

/* Align Home and Summary buttons to the left */
.nav-buttons {
    display: flex;
    gap: 10px;
}

/* Logout button aligned to the right */
.logout-btn {
    background: red;
    color: white;
    border: none;
    padding: 8px 15px;
    cursor: pointer;
    font-size: 16px;
    border-radius: 5px;
    margin-left: auto; /* Pushes logout button to the right */
}

/* Button Styling */
.nav-btn {
    background: rgb(255, 255, 255);
    color: #007bff;
    border: none;
    padding: 8px 15px;
    cursor: pointer;
    font-size: 16px;
    border-radius: 5px;
}

/* Navbar Buttons */
.logout-btn {
    background: white;
    color: #007bff;
    border: none;
    padding: 10px 16px;
    cursor: pointer;
    font-size: 16px;
    font-weight: bold;
    border-radius: 5px;
    transition: all 0.3s ease;
}

.nav-btn:hover {
    background: #0056b3;
    color: white;
}

.logout-btn {
    background: red;
    color: white;
}

.logout-btn:hover {
    background: darkred;
}

/* Form Container */
.form-container {
    margin-top: 90px;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px;
}

/* Title */
.title {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
    color: #333;
    text-align: center;
}

/* Question Form */
.question-form {
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: 90%;
    max-width: 500px;
    display: flex;
    flex-direction: column;
    gap: 10px;
}

/* Labels */
label {
    font-size: 16px;
    font-weight: bold;
    margin-bottom: 5px;
    color: #333;
}

/* Input Fields */
.input-field {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
    transition: border 0.3s ease-in-out;
}

.input-field:focus {
    border: 1px solid #007bff;
    outline: none;
}

/* Options */
.option-group {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 5px 0;
}

/* Save Button */
.save-btn {
    background: #007bff;
    color: white;
    font-size: 16px;
    padding: 12px;
    font-weight: bold;
    border-radius: 5px;
    cursor: pointer;
    border: none;
    transition: background 0.3s ease-in-out;
}

.save-btn:hover {
    background: #0056b3;
}

/* Loading Text */
.loading-text {
    font-size: 18px;
    color: gray;
    text-align: center;
    margin-top: 20px;
}

/* Responsive Design */
@media (max-width: 768px) {
    .question-form {
        width: 95%;
        padding: 15px;
    }

    .nav-btn, .logout-btn {
        padding: 8px 12px;
        font-size: 14px;
    }
}

</style>