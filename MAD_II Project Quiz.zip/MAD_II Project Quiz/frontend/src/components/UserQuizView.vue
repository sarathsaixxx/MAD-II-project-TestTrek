<template>
  <div>
    <nav class="navbar bg-primary" data-bs-theme="dark">
      <button @click="goBack" class="nav-btn">Back</button> &nbsp;
      <button @click="logout" class="logout-btn">Logout</button>
    </nav>

    <h3>------------------------------------------------------------</h3>
    <h2 class="text-lg font-bold mb-4">Quiz Details</h2>

    <div v-if="quiz" class="quiz-details"> 
      <p><strong>Date:</strong> {{ quiz.date }}</p>
      <p><strong>Time Duration:</strong> {{ quiz.time_duration }}</p>
      <p><strong>Remarks:</strong> {{ quiz.remarks }}</p>
      <p><strong>Subject Name:</strong> {{ quiz.subject }}</p>
      <p><strong>Chapter Name:</strong> {{ quiz.chapter }}</p>
    </div>

    <div v-else>
      <p>Loading quiz details...</p>
    </div>
 
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      quiz: null,
      quiz_id: this.$route.params.quiz_id,
      user_id:this.$route.params.user_id // Get quiz ID from route params
    };
  },
  methods: {
    async fetchQuizDetails() {
      try {
        const response = await axios.get(`http://127.0.0.1:5000/quiz/${this.quiz_id}`);
        if (response.status === 200) {
          this.quiz = response.data;
        } else {
          console.error("Error fetching quiz details:", response.statusText);
        }
      } catch (error) {
        console.error("API request failed:", error.message);
      }
    },

    goBack() {
      this.$router.push(`/dashboard/${this.user_id}`); // Navigate back to quiz list
    },
    logout() {
      axios.post('http://localhost:5000/logout', {}, { withCredentials: true })
        .then(() => {
          console.log("Logout successful");  // Debugging
          localStorage.removeItem('token');
          this.$router.push('/login');
        })
        .catch(error => {
          console.error('Logout error:', error);
          alert('Logout failed! Check the console for details.');
        });
    },
  },

  mounted() {
    console.log("Received quiz_id:", this.quiz_id);
    this.fetchQuizDetails();
  },
};
</script>

<style scoped>
div {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
}

.navbar {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  background-color: #007bff;
  padding: 10px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: white;
}

.nav-btn {
  background: white;
  color: #007bff;
  border: none;
  padding: 8px 15px;
  cursor: pointer;
  font-size: 16px;
  border-radius: 5px;
}

.logout-btn {
  background: red;
  color: white;
  border: none;
  padding: 8px 15px;
  cursor: pointer;
  font-size: 16px;
  border-radius: 5px;
  margin-left: auto;
}

.quiz-details {
  background: #f9f9f9;
  padding: 20px;
  border-radius: 10px;
  border: 1px solid #ccc;
  width: 50%;
}

.add-questions-btn {
  background: green;
  color: white;
  border: none;
  padding: 10px 20px;
  cursor: pointer;
  font-size: 16px;
  border-radius: 5px;
  margin-top: 20px;
}
</style>
