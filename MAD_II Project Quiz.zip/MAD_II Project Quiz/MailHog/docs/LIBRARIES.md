MailHog libraries
=================

If you've created a MailHog client library, open a pull request and add it!

* [APIv2 library for NodeJS](https://github.com/blueimp/mailhog-node)
* [APIv1/APIv2 library for PHP](https://github.com/rpkamp/mailhog-client)
